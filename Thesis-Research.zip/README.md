# Thesis Research
Using Deep Neural Networks for Acoustic Underwater Channel Estimation in non-LTI systems

Research Done with Dr. Song's Lab at The University of Alabama
